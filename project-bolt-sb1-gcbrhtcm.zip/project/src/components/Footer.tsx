import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Code, Coffee } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="py-16 border-t border-gray-800 bg-black relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute bottom-0 left-20 w-64 h-64 bg-purple-600 rounded-full mix-blend-multiply filter blur-xl"></div>
        <div className="absolute bottom-0 right-20 w-64 h-64 bg-blue-600 rounded-full mix-blend-multiply filter blur-xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row justify-between items-center gap-6"
        >
          <div className="flex items-center gap-2 text-gray-400">
            <p>© 2025 Sone Lokhande. Made with</p>
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity, ease: "easeInOut" }}
            >
              <Heart className="w-4 h-4 text-red-500 fill-current" />
            </motion.div>
            <p>and</p>
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            >
              <Code className="w-4 h-4 text-blue-400" />
            </motion.div>
            <p>and lots of</p>
            <motion.div
              animate={{ y: [0, -2, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
            >
              <Coffee className="w-4 h-4 text-amber-500" />
            </motion.div>
          </div>
          
          <div className="flex gap-8">
            {[
              { name: 'LinkedIn', href: '#', color: 'hover:text-blue-400' },
              { name: 'GitHub', href: '#', color: 'hover:text-gray-300' },
              { name: 'Twitter', href: '#', color: 'hover:text-sky-400' }
            ].map((social) => (
              <motion.a
                key={social.name}
                href={social.href}
                whileHover={{ y: -2, scale: 1.05 }}
                className={`text-gray-500 ${social.color} transition-all duration-300 font-medium`}
              >
                {social.name}
              </motion.a>
            ))}
          </div>
        </motion.div>

        {/* Additional Footer Content */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="mt-8 pt-8 border-t border-gray-800 text-center"
        >
          <p className="text-gray-500 text-sm">
            Specializing in WordPress & Shopify Development • Custom E-commerce Solutions • Available for Hire
          </p>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;