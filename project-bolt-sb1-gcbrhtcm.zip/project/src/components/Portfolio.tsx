import React, { useState, useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { ExternalLink, ChevronLeft, ChevronRight, Filter, Star, Calendar, Users } from 'lucide-react';

const Portfolio = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [filter, setFilter] = useState('all');
  const [currentSlide, setCurrentSlide] = useState(0);

  const projects = [
    {
      title: 'Atulya Karigari',
      description: 'Premium e-commerce platform with custom Shopify sections, advanced payment integration, and optimized conversion funnel.',
      url: 'https://www.atulyakarigari.com/',
      category: 'shopify',
      tech: ['Shopify', 'Liquid', 'HTML/CSS', 'E-commerce'],
      image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=800',
      featured: true,
      year: '2024',
      client: 'Atulya Karigari'
    },
    {
      title: 'Dream Beauty',
      description: 'Elegant beauty e-commerce platform with custom liquid implementations and seamless checkout experience.',
      url: 'https://dreambeauty.co.in/',
      category: 'shopify',
      tech: ['Shopify', 'Liquid', 'Beauty', 'Responsive'],
      image: 'https://images.pexels.com/photos/3373736/pexels-photo-3373736.jpeg?auto=compress&cs=tinysrgb&w=800',
      featured: true,
      year: '2024',
      client: 'Dream Beauty'
    },
    {
      title: 'Chinh Hari Arts',
      description: 'Creative arts platform with custom Shopify sections and artistic design elements.',
      url: 'https://chinhhariarts.org/',
      category: 'shopify',
      tech: ['Shopify', 'Custom Sections', 'Arts', 'Creative'],
      image: 'https://images.pexels.com/photos/1183992/pexels-photo-1183992.jpeg?auto=compress&cs=tinysrgb&w=800',
      featured: false,
      year: '2023',
      client: 'Chinh Hari Arts'
    },
    {
      title: 'The Girl Boss',
      description: 'Modern fashion e-commerce with integrated payments and advanced shipping solutions.',
      url: 'https://thegirlboss.in/',
      category: 'shopify',
      tech: ['Shopify', 'Fashion', 'Payment Gateway', 'Shipping'],
      image: 'https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=800',
      featured: true,
      year: '2024',
      client: 'The Girl Boss'
    },
    {
      title: 'Amado',
      description: 'Custom WordPress website with tailored design and responsive layout optimization.',
      url: 'https://amado.co.in/',
      category: 'wordpress',
      tech: ['WordPress', 'HTML/CSS', 'Responsive', 'Custom'],
      image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
      featured: false,
      year: '2023',
      client: 'Amado'
    },
    {
      title: 'Annamrit',
      description: 'WordPress e-commerce solution with WooCommerce integration and custom styling.',
      url: 'https://annamrit.in/',
      category: 'wordpress',
      tech: ['WordPress', 'WooCommerce', 'E-commerce', 'Custom CSS'],
      image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800',
      featured: true,
      year: '2024',
      client: 'Annamrit'
    },
    {
      title: 'Shubh Aangan',
      description: 'Professional WordPress website with modern design and optimized performance.',
      url: 'https://shubh-aangan.com/',
      category: 'wordpress',
      tech: ['WordPress', 'HTML/CSS', 'Business', 'Modern'],
      image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800',
      featured: false,
      year: '2023',
      client: 'Shubh Aangan'
    },
    {
      title: 'Shreyam',
      description: 'Corporate WordPress development with focus on user experience and SEO optimization.',
      url: 'https://shreyam.co.in/',
      category: 'wordpress',
      tech: ['WordPress', 'Corporate', 'SEO', 'Performance'],
      image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=800',
      featured: true,
      year: '2024',
      client: 'Shreyam'
    }
  ];

  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(project => project.category === filter);

  const filters = [
    { key: 'all', label: 'All Projects', count: projects.length },
    { key: 'shopify', label: 'Shopify', count: projects.filter(p => p.category === 'shopify').length },
    { key: 'wordpress', label: 'WordPress', count: projects.filter(p => p.category === 'wordpress').length }
  ];

  const projectsPerSlide = 2;
  const totalSlides = Math.ceil(filteredProjects.length / projectsPerSlide);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % totalSlides);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);
  };

  const getVisibleProjects = () => {
    const startIndex = currentSlide * projectsPerSlide;
    return filteredProjects.slice(startIndex, startIndex + projectsPerSlide);
  };

  return (
    <section id="work" className="py-32 bg-black relative overflow-hidden" ref={ref}>
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-40 right-20 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
        <div className="absolute bottom-40 left-20 w-96 h-96 bg-blue-600 rounded-full mix-blend-multiply filter blur-xl animate-pulse" style={{ animationDelay: '3s' }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-black text-white mb-6 tracking-tight">
            Featured Projects
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Showcasing my expertise in creating professional e-commerce solutions and web applications
          </p>
        </motion.div>

        {/* Enhanced Filter Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex justify-center gap-4 mb-16 flex-wrap"
        >
          {filters.map((filterItem) => (
            <motion.button
              key={filterItem.key}
              onClick={() => {
                setFilter(filterItem.key);
                setCurrentSlide(0);
              }}
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 flex items-center gap-2 ${
                filter === filterItem.key
                  ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg shadow-purple-500/25'
                  : 'bg-gray-800/50 border border-gray-700 text-gray-300 hover:text-white hover:border-gray-600 hover:bg-gray-700/50'
              }`}
            >
              <Filter className="w-4 h-4" />
              {filterItem.label}
              <span className={`text-xs px-2 py-1 rounded-full ${
                filter === filterItem.key ? 'bg-white/20' : 'bg-gray-700'
              }`}>
                {filterItem.count}
              </span>
            </motion.button>
          ))}
        </motion.div>

        {/* Enhanced Project Slider */}
        <div className="relative">
          {/* Navigation */}
          <div className="flex justify-between items-center mb-8">
            <motion.button
              onClick={prevSlide}
              whileHover={{ scale: 1.1, x: -2 }}
              whileTap={{ scale: 0.95 }}
              disabled={totalSlides <= 1}
              className="p-4 bg-gray-800/50 hover:bg-gray-700/50 border border-gray-700 rounded-full text-white transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-6 h-6" />
            </motion.button>

            <div className="text-center">
              <span className="text-gray-400 font-medium">
                {currentSlide + 1} of {totalSlides}
              </span>
              <div className="flex justify-center gap-2 mt-2">
                {Array.from({ length: totalSlides }).map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      currentSlide === index ? 'bg-purple-500 w-6' : 'bg-gray-600 hover:bg-gray-500'
                    }`}
                  />
                ))}
              </div>
            </div>

            <motion.button
              onClick={nextSlide}
              whileHover={{ scale: 1.1, x: 2 }}
              whileTap={{ scale: 0.95 }}
              disabled={totalSlides <= 1}
              className="p-4 bg-gray-800/50 hover:bg-gray-700/50 border border-gray-700 rounded-full text-white transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ChevronRight className="w-6 h-6" />
            </motion.button>
          </div>

          {/* Enhanced Project Cards */}
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.5 }}
            className="grid md:grid-cols-2 gap-8"
          >
            {getVisibleProjects().map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 50 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
                transition={{ duration: 0.6, delay: 0.4 + index * 0.1 }}
                whileHover={{ y: -10, transition: { duration: 0.3 } }}
                className="group bg-gradient-to-br from-gray-900/80 to-gray-800/80 backdrop-blur-sm border border-gray-700/50 rounded-3xl overflow-hidden hover:border-purple-500/50 hover:from-gray-800/80 hover:to-gray-700/80 transition-all duration-500"
              >
                {/* Project Preview */}
                <div className="h-64 relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-60 group-hover:opacity-40 transition-opacity duration-300"></div>
                  
                  {/* Featured Badge */}
                  {project.featured && (
                    <div className="absolute top-4 left-4 bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1">
                      <Star className="w-3 h-3 fill-current" />
                      Featured
                    </div>
                  )}

                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <motion.a
                      href={project.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.95 }}
                      className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-6 py-3 rounded-full font-semibold flex items-center gap-2 shadow-lg"
                    >
                      View Live
                      <ExternalLink className="w-4 h-4" />
                    </motion.a>
                  </div>
                </div>

                {/* Enhanced Project Content */}
                <div className="p-8">
                  {/* Project Meta */}
                  <div className="flex items-center gap-4 mb-4 text-sm text-gray-400">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {project.year}
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {project.client}
                    </div>
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-3 tracking-tight group-hover:text-purple-400 transition-all duration-300">
                    {project.title}
                  </h3>
                  <p className="text-gray-400 mb-6 leading-relaxed">
                    {project.description}
                  </p>

                  {/* Enhanced Tech Stack */}
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.tech.map((tech, techIndex) => (
                      <span
                        key={tech}
                        className={`px-3 py-1 bg-gray-800/50 border border-gray-700 text-gray-300 text-sm rounded-full hover:bg-gray-700/50 hover:text-white transition-all duration-200 ${
                          techIndex === 0 ? 'bg-purple-600/20 border-purple-500/30 text-purple-300' : ''
                        }`}
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  {/* Project Link */}
                  <motion.a
                    href={project.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ x: 5 }}
                    className="inline-flex items-center gap-2 text-white font-semibold hover:text-purple-400 transition-all duration-300 group-hover:text-purple-300"
                  >
                    Visit Website
                    <ExternalLink className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </motion.a>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;