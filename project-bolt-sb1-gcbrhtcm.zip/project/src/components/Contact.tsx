import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Mail, Github, Linkedin, Twitter, Send, MapPin, Phone, Briefcase, Clock, CheckCircle } from 'lucide-react';

const Contact = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="contact" className="py-32 bg-black relative overflow-hidden" ref={ref}>
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-72 h-72 bg-purple-600 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-72 h-72 bg-blue-600 rounded-full mix-blend-multiply filter blur-xl animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="max-w-6xl mx-auto px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-green-600/20 border border-green-500/30 text-green-400 px-4 py-2 rounded-full text-sm font-medium mb-6">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            Open to Job Opportunities
          </div>
          
          <h2 className="text-4xl md:text-6xl font-black text-white tracking-tight mb-6">
            Let's Work Together
          </h2>
          
          <p className="text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
            I'm actively seeking new opportunities as a WordPress/Shopify Developer. 
            Ready to contribute to your team's success with my expertise in e-commerce development.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            {/* Email */}
            <motion.div
              whileHover={{ scale: 1.02, x: 10 }}
              className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 backdrop-blur-sm border border-gray-700/50 rounded-3xl p-8 hover:border-purple-500/50 hover:from-gray-800/80 hover:to-gray-700/80 transition-all duration-300"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-purple-600/20 rounded-xl">
                  <Mail className="w-6 h-6 text-purple-400" />
                </div>
                <h3 className="text-xl font-semibold text-white">Email Me</h3>
              </div>
              <motion.a
                href="mailto:lokhandesonu113@gmail.com"
                whileHover={{ scale: 1.05 }}
                className="text-xl md:text-2xl font-bold text-purple-400 hover:text-purple-300 transition-all duration-300 break-all"
              >
                lokhandesonu113@gmail.com
              </motion.a>
            </motion.div>

            {/* Phone */}
            <motion.div
              whileHover={{ scale: 1.02, x: 10 }}
              className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 backdrop-blur-sm border border-gray-700/50 rounded-3xl p-8 hover:border-blue-500/50 hover:from-gray-800/80 hover:to-gray-700/80 transition-all duration-300"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-blue-600/20 rounded-xl">
                  <Phone className="w-6 h-6 text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold text-white">Call Me</h3>
              </div>
              <motion.a
                href="tel:+918839963663"
                whileHover={{ scale: 1.05 }}
                className="text-xl md:text-2xl font-bold text-blue-400 hover:text-blue-300 transition-all duration-300"
              >
                +91 8839963663
              </motion.a>
            </motion.div>

            {/* Availability */}
            <motion.div
              whileHover={{ scale: 1.02, x: 10 }}
              className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 backdrop-blur-sm border border-gray-700/50 rounded-3xl p-8 hover:border-green-500/50 hover:from-gray-800/80 hover:to-gray-700/80 transition-all duration-300"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-green-600/20 rounded-xl">
                  <Clock className="w-6 h-6 text-green-400" />
                </div>
                <h3 className="text-xl font-semibold text-white">Availability</h3>
              </div>
              <p className="text-lg text-gray-300 mb-2">Available for immediate start</p>
              <p className="text-sm text-gray-400">Remote work preferred • Open to relocation</p>
            </motion.div>
          </motion.div>

          {/* Hiring CTA Section */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 backdrop-blur-sm border border-gray-700/50 rounded-3xl p-8 lg:p-12"
          >
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-purple-600/20 rounded-xl">
                <Briefcase className="w-6 h-6 text-purple-400" />
              </div>
              <h3 className="text-3xl font-bold text-white">Ready to Hire?</h3>
            </div>
            
            <p className="text-gray-300 mb-8 leading-relaxed">
              I bring 3+ years of experience in WordPress and Shopify development, with a proven track record 
              of delivering high-quality e-commerce solutions. Let's discuss how I can contribute to your team.
            </p>

            {/* Key Strengths */}
            <div className="space-y-4 mb-8">
              {[
                'Custom E-commerce Development',
                'Shopify & WordPress Expertise',
                'Payment Gateway Integration',
                'Responsive Design & Performance'
              ].map((strength, index) => (
                <motion.div
                  key={strength}
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                  transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span className="text-gray-300">{strength}</span>
                </motion.div>
              ))}
            </div>

            <div className="space-y-6">
              <motion.a
                href="mailto:lokhandesonu113@gmail.com?subject=Job Opportunity - WordPress/Shopify Developer&body=Hi Sone, I'd like to discuss a job opportunity with you."
                whileHover={{ 
                  scale: 1.05, 
                  y: -2,
                  boxShadow: "0 20px 40px rgba(168, 85, 247, 0.4)"
                }}
                whileTap={{ scale: 0.95 }}
                className="w-full inline-flex items-center justify-center gap-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 group shadow-lg shadow-purple-500/25"
              >
                <Mail className="w-5 h-5" />
                Contact for Job Opportunities
                <Send className="w-5 h-5 transition-transform group-hover:translate-x-1" />
              </motion.a>

              <motion.a
                href="tel:+918839963663"
                whileHover={{ 
                  scale: 1.05, 
                  y: -2,
                  boxShadow: "0 20px 40px rgba(59, 130, 246, 0.4)"
                }}
                whileTap={{ scale: 0.95 }}
                className="w-full inline-flex items-center justify-center gap-3 bg-gray-800 hover:bg-gray-700 border border-gray-600 hover:border-gray-500 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 group shadow-lg"
              >
                <Phone className="w-5 h-5" />
                Call Now for Interview
              </motion.a>

              <div className="text-center">
                <p className="text-gray-500 mb-4">Or connect with me on</p>
                {/* Social Links */}
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                  transition={{ duration: 0.6, delay: 0.6 }}
                  className="flex justify-center gap-4"
                >
                  {[
                    { icon: Linkedin, href: '#', label: 'LinkedIn', color: 'bg-blue-600 hover:bg-blue-700' },
                    { icon: Github, href: '#', label: 'GitHub', color: 'bg-gray-700 hover:bg-gray-600' },
                    { icon: Twitter, href: '#', label: 'Twitter', color: 'bg-sky-600 hover:bg-sky-700' }
                  ].map(({ icon: Icon, href, label, color }) => (
                    <motion.a
                      key={label}
                      href={href}
                      whileHover={{ y: -3, scale: 1.1 }}
                      whileTap={{ scale: 0.95 }}
                      className={`p-3 text-white ${color} rounded-full transition-all duration-300 hover:shadow-lg`}
                      aria-label={label}
                    >
                      <Icon className="w-5 h-5" />
                    </motion.a>
                  ))}
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;