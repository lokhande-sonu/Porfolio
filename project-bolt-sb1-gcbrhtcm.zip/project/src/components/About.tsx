import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Code, Palette, Zap, Globe, ShoppingCart, Smartphone, Award, Target, User, Briefcase } from 'lucide-react';

const About = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const skills = [
    { name: 'WordPress Development', icon: Globe, level: 95, color: 'from-blue-500 to-blue-600' },
    { name: 'Shopify Custom Themes', icon: ShoppingCart, level: 90, color: 'from-green-500 to-green-600' },
    { name: 'Liquid Code Programming', icon: Code, level: 88, color: 'from-purple-500 to-purple-600' },
    { name: 'HTML/CSS/JavaScript', icon: Palette, level: 92, color: 'from-orange-500 to-orange-600' },
    { name: 'E-commerce Solutions', icon: ShoppingCart, level: 85, color: 'from-pink-500 to-pink-600' },
    { name: 'Responsive Design', icon: Smartphone, level: 90, color: 'from-cyan-500 to-cyan-600' }
  ];

  const achievements = [
    { number: '50+', label: 'Projects Completed', icon: Target, color: 'text-purple-400' },
    { number: '3+', label: 'Years Experience', icon: Award, color: 'text-blue-400' },
    { number: '100%', label: 'Client Satisfaction', icon: Zap, color: 'text-green-400' },
    { number: '24/7', label: 'Support Available', icon: Globe, color: 'text-orange-400' }
  ];

  return (
    <section id="about" className="py-32 bg-black relative overflow-hidden" ref={ref}>
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-72 h-72 bg-purple-600 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-72 h-72 bg-blue-600 rounded-full mix-blend-multiply filter blur-xl animate-pulse" style={{ animationDelay: '3s' }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <motion.h2
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-4xl md:text-6xl font-black text-white mb-16 tracking-tight text-center"
        >
          About Me
        </motion.h2>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-16 items-start mb-20">
          {/* Professional Summary */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            {/* Profile Card */}
            <div className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 backdrop-blur-sm border border-gray-700/50 rounded-3xl p-8 hover:border-purple-500/30 transition-all duration-300">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-purple-600/20 rounded-xl">
                  <User className="w-6 h-6 text-purple-400" />
                </div>
                <h3 className="text-2xl font-bold text-white">Professional Summary</h3>
              </div>
              <p className="text-gray-300 leading-relaxed mb-6">
                I'm a dedicated WordPress and Shopify developer with over 3 years of experience creating 
                high-performance e-commerce solutions. I specialize in custom theme development, 
                payment gateway integrations, and performance optimization.
              </p>
              <p className="text-gray-300 leading-relaxed">
                My expertise in Liquid programming and modern web technologies allows me to deliver 
                scalable, maintainable solutions that drive business growth and enhance user experience.
              </p>
            </div>

            {/* Career Objective */}
            <div className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 backdrop-blur-sm border border-gray-700/50 rounded-3xl p-8 hover:border-blue-500/30 transition-all duration-300">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-blue-600/20 rounded-xl">
                  <Briefcase className="w-6 h-6 text-blue-400" />
                </div>
                <h3 className="text-2xl font-bold text-white">Career Objective</h3>
              </div>
              <p className="text-gray-300 leading-relaxed">
                Seeking a challenging role as a Senior WordPress/Shopify Developer where I can leverage 
                my technical expertise and creative problem-solving skills to contribute to innovative 
                e-commerce projects and drive digital transformation.
              </p>
            </div>
          </motion.div>

          {/* Enhanced Skills Section */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="space-y-8"
          >
            <div className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 backdrop-blur-sm border border-gray-700/50 rounded-3xl p-8 hover:border-green-500/30 transition-all duration-300">
              <div className="flex items-center gap-4 mb-8">
                <div className="p-3 bg-green-600/20 rounded-xl">
                  <Code className="w-6 h-6 text-green-400" />
                </div>
                <h3 className="text-2xl font-bold text-white">Technical Skills</h3>
              </div>
              <div className="space-y-6">
                {skills.map((skill, index) => {
                  const Icon = skill.icon;
                  return (
                    <motion.div
                      key={skill.name}
                      initial={{ opacity: 0, x: 30 }}
                      animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 30 }}
                      transition={{ duration: 0.6, delay: 0.6 + index * 0.1 }}
                      className="group"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-gray-800/50 rounded-lg group-hover:bg-gray-700/50 transition-all duration-200">
                            <Icon className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors duration-200" />
                          </div>
                          <span className="text-white font-medium group-hover:text-gray-200 transition-colors duration-200">{skill.name}</span>
                        </div>
                        <span className="text-gray-400 text-sm font-semibold">{skill.level}%</span>
                      </div>
                      <div className="w-full bg-gray-800 rounded-full h-3 overflow-hidden">
                        <motion.div
                          className={`bg-gradient-to-r ${skill.color} h-3 rounded-full relative overflow-hidden`}
                          initial={{ width: 0 }}
                          animate={isInView ? { width: `${skill.level}%` } : { width: 0 }}
                          transition={{ duration: 1.2, delay: 0.8 + index * 0.1, ease: "easeOut" }}
                        >
                          <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                        </motion.div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        </div>

        {/* Enhanced Achievements Grid */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6"
        >
          {achievements.map((achievement, index) => {
            const Icon = achievement.icon;
            return (
              <motion.div
                key={achievement.label}
                initial={{ opacity: 0, y: 30, scale: 0.9 }}
                animate={isInView ? { opacity: 1, y: 0, scale: 1 } : { opacity: 0, y: 30, scale: 0.9 }}
                transition={{ duration: 0.6, delay: 1 + index * 0.1 }}
                whileHover={{ y: -8, scale: 1.05 }}
                className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 text-center hover:border-purple-500/50 transition-all duration-300 group cursor-pointer"
              >
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-gray-800/50 rounded-full group-hover:bg-gray-700/50 transition-all duration-300">
                    <Icon className={`w-6 h-6 ${achievement.color} group-hover:scale-110 transition-transform duration-300`} />
                  </div>
                </div>
                <div className="text-3xl font-bold text-white mb-2 group-hover:text-purple-300 transition-colors duration-300">
                  {achievement.number}
                </div>
                <div className="text-gray-400 text-sm group-hover:text-gray-300 transition-colors duration-300">
                  {achievement.label}
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};

export default About;